package com.himedia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardJpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(BoardJpaApplication.class, args);
    }

}
